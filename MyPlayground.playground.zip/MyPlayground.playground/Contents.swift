import UIKit

var saludo = "Hola Mundo"
// Ejercicio 1
// Alberto


// Ejercicio 1

// Alberto

// Ejercicio 2

/* Nombre
 edad
 Carrera
 */


// Ejercicio 3

let cadena = "Cadena"
let boleano = true
let entero = 22

// Ejercicio 4
let uno: String?
let dos: Int?
let tres: Bool?
let cuatro: Double?

// Ejercicio 5
let unoValor: String = "Valor"
let dosValor: Int = 2
let tresValor: Bool = false
let cuatroValor: Double = 3.2

// Ejercicio 6
let nombre = "Alberto"
let apellido = "Besne"
var edad = 22


